﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Repositories.Interfaces;

namespace WebApplication1.Repositories.Implementations
{
    public class StudentRepository : GenericRepository<Student>, IStudentRepository
    {
        public StudentRepository(ApplicationDbContext context) : base(context) { }

        public async Task<Student?> GetByNationalIdAsync(string nationalId) =>
            await _dbSet
                .Include(s => s.Level)
                .Include(s => s.Division)
                .FirstOrDefaultAsync(s => s.NationalId == nationalId);

        public async Task<bool> NationalIdExistsAsync(string nationalId) =>
            await _dbSet.AnyAsync(s => s.NationalId == nationalId);

        public async Task<IEnumerable<Student>> GetByLevelAsync(int levelId) =>
            await _dbSet
                .Include(s => s.Level)
                .Include(s => s.Division)
                .Where(s => s.LevelId == levelId)
                .ToListAsync();

        public async Task<IEnumerable<Student>> GetByDivisionAsync(int divisionId) =>
            await _dbSet
                .Include(s => s.Level)
                .Include(s => s.Division)
                .Where(s => s.DivisionId == divisionId)
                .ToListAsync();

        public async Task<IEnumerable<Student>> GetByLevelAndDivisionAsync(int levelId, int divisionId) =>
            await _dbSet
                .Include(s => s.Level)
                .Include(s => s.Division)
                .Where(s => s.LevelId == levelId && s.DivisionId == divisionId)
                .ToListAsync();

        public async Task<IEnumerable<Student>> GetAllWithDetailsAsync() =>
            await _dbSet
                .Include(s => s.Level)
                .Include(s => s.Division)
                .OrderBy(s => s.FullName)
                .ToListAsync();
    }
}